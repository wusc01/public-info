const ldap = require('ldapjs');

const config = {
    ldapURL: 'ldap://xxxx', // LDAP 服务器地址，加不加端口号以实际为准，我的项目中加端口号无法连接
    adminDN: 'CN=,DC=example,DC=com', // 用户信息，必须是从根节点到用户节点的全路径,有可能有 OU、UID
    adminPwd: 'xxx', // 用户密码
    searchDn: 'DC=example,DC=com', // 查询基础路径，代表查询用户信息在这个路径下进行，由根节点开始
};

// 创建客户端
const ldapClient = ldap.createClient({
    url: config.ldapURL,
});

// 监听 error 事件
ldapClient.on('error', err => {
    console.log('ldap error', err);
});

// 监听 connect 事件
ldapClient.on('connect', () => {
    console.log('ldap connect');
});

// 将 client 绑定 LDAP Server
ldapClient.bind(config.adminDN, config.adminPwd, (bindErr, bindRes) => {
    // 查询配置
    const opts = {
        filter: `username=${username}`, // 查询条件过滤器，查询 username 为 xx 的数据
        scope: 'sub', // 查询范围
        timeLimit: 500, // 查询超时
        attributes: ['username', 'org'] // 选择返回的数据属性
    };

    // 处理查询事件
    ldapClient.search(config.searchDn, opts, (searchErr, searchRes) => {

        // 监听查询结果事件
        searchRes.on('searchEntry', entry => {

            // 获取查询的对象
            const user = entry.object;

            console.log('查询结果：', user);
        });

        // 监听查询错误事件
        searchRes.on('error', error => {
            ldapClient.unbind();
            console.log('查询失败：', error);
        });

        // 监听查询结束事件
        searchRes.on('end', result => {
            ldapClient.unbind();
        });
    });
});

// 作者：慢时光
// 链接：https://juejin.cn/post/7089337182690738206
// 来源：稀土掘金
// 著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。