var { Graph } = require("graph-data-structure");
var graph = Graph()
  .addEdge("socks", "shoes")
  .addEdge("shirt", "belt")
  .addEdge("shirt", "tie")
  .addEdge("tie", "jacket")
  .addEdge("belt", "jacket")
  .addEdge("pants", "shoes")
  .addEdge("underpants", "pants")
  .addEdge("pants", "belt")
  .addEdge("a", "b")
  .addEdge("b", "c")
  ;

  console.log(graph.topologicalSort(['a']));
  console.log(graph.topologicalSort(['b']));
  console.log(graph.topologicalSort(['belt']));
console.log(graph.serialize());
console.log(graph.nodes());